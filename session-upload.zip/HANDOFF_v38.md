# MixelParse Handoff — v38

## Files changed this session
| File | Destination |
|---|---|
| `index.html` | `src/` |

`index.html` — 8,022 lines (up from 7,901 in v37)

---

## What was done this session

### 1. Help content — cogwheel filter tips
- `sub_factions`: City bar tip rewritten to explicitly mention the ⚙ button per city ("Each city bar has its own ⚙ button — click it to show or hide that city's standings independently")
- `sub_quests`: New tip added explaining the ⚙ category filter (Gold chip = visible, dim = hidden; categories listed)

### 2. Zone bar — bankers separated
- `renderZoneBar()`: Bankers filtered out of the main floating zone grid via `.filter(([char])=>!isBanker(char))`
- `renderBankersPanel()`: Zone section injected above the Add Banker row using the same `.zone-bar-grid` layout. Shows each banker's current zone. Section is hidden entirely if no banker has zone data yet. Order: header → Zone Locations → Add Banker → banker list.

### 3. v1.0 checkpoint
- `index_v1.0_checkpoint.html` saved and downloaded before inventory/planner work began. MD5: `fb6c818047a59de1dad2b6bcb36d9197`

### 4. Inventory — class filter
- New `<select id="classFilter">` dropdown added next to location filter (14 classes, 3-letter abbrevs matching `_classes` field)
- `renderTable()`: When classFilter active, requires DB entry + `_slot !== 'NONE'`, filters by class abbrev against `db._classes`
- Clear button and event listener wired

### 5. Inventory — slot filter
- New `<select id="slotFilter">` dropdown added (21 slots grouped: Head & Neck / Body / Accessories / Weapons & Shields / Ranged)
- When classFilter OR slotFilter active: items with no DB entry or `_slot === 'NONE'` are excluded entirely (no `?` badge — clean exclusion)
- Multi-slot items checked against `db._slots` array
- Clear button and event listener wired

### 6. Gear Planner — inventory availability (`_invAvail`)
Built inside `renderUpgradesPanel()` before the cards loop:
```js
window._upgInvAvail = _invAvail;
// keyed by item name → [{char, type:'char'|'banker'}]
// Regular chars: non-equipped only
// Bankers: ALL items including equipped slots
```

Availability shown in two places:
- **Compare dropdown options**: `★ CharName` appended to label; bankers shown as `★ [BankerName]` (brackets). Rebuilt in `upgSwapAlt` using `window._upgInvAvail`.
- **Right pane** (on item select): Green `.upg-avail-badge` div below item name — `★ CharName · Banker: Mixelvault`

### 7. Gear Planner Reports — availability in saved plans
- `renderGearReportsPanel()`: Same `invAvail` lookup built at top of function
- Each plan row with `e.upgradeName`: green `.upg-avail-badge` injected under item name showing who has it
- **Total Plat** excludes items found in inventory (`platExcludedCount` tracked). Excluded items do NOT reduce Total DKP (raid drops still need to be bid)
- Note shown under Total Plat: `N items in inventory excluded`

### 8. Banker equipped items included in availability
Both `_invAvail` builds (renderUpgradesPanel + renderGearReportsPanel) changed from:
```js
if(locationType(_citem.location)!=='equipped')
```
to:
```js
if(_isBnk || locationType(_citem.location)!=='equipped')
```
Bankers' entire inventory (bags, bank, AND equipped slots) counts as available.

---

## CSS added
```css
.upg-avail-badge { font-size:.72rem; color:#3a7a3a; font-weight:600; margin:.15rem 0 .1rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis }
```

---

## Known issues carried forward
- `watchList is not defined` IPC error in `renderWatchlistBar`
- Banker drag-wrong-file UX (wrong tab left behind)
- `/note hourly` session creation — pending in-game test
- Zone bar persistence after `currentUser` fix — pending in-game test

---

## Open roadmap items
- Weapon stats for stat calc (damage, ratio, proc, MH/OH scoring)
- Quest item flagging (wiki crawl for ingredients)
- Mobile-friendly layout pass
- PigParse / custom timers with SMS
- Discord webhook integration for timers
- Stat weight profiles (Raider vs. Solo toggle)
- Best in Slot vs. Realistic toggle
- Zone tracking timestamped history (stretch)
- Companion app / MixelParse.exe
- UI Copy Tool (copy `UI_<CharName>_P1999Green.ini` between toons)
- Bankers tab — full migration of Mixelvault/Mixelbank out of roster *(registry done; zone section done)*
